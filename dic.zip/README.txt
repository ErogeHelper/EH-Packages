﻿This directory contains defaulted IPADIC files.
